#! /bin/bash

python /home/core/r2ac/r2ac.py 10.0.2.10 &
sleep 13
python /home/core/r2ac/deviceSimulator.py 100 100 &
