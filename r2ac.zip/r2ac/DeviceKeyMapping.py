class DeviceKeyMapping:
    def __init__(self, publicKey, AESKey):
        self.publicKey = publicKey
        self.AESKey = AESKey
