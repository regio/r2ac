class PeerInfo:
    def __init__(self, peerURI,  object):
        self.peerURI = peerURI
        self.object = object


